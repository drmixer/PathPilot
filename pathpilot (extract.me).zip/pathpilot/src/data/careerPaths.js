export const careerPaths = {
  software: {
    title: "Software Engineer",
    description: "Build applications and systems that power the modern world",
  },
  data: {
    title: "Data Scientist",
    description: "Extract insights from data to drive business decisions",
  },
  design: {
    title: "UX Designer",
    description: "Create intuitive and delightful user experiences",
  },
};
