export const learningModules = {
  software: [
    {
      title: "Programming Foundations",
      timeEstimate: "4 weeks",
    },
    {
      title: "Web Development",
      timeEstimate: "8 weeks",
    },
  ],
  data: [
    {
      title: "Data Analysis Basics",
      timeEstimate: "6 weeks",
    },
  ],
  design: [
    {
      title: "User Experience Fundamentals",
      timeEstimate: "5 weeks",
    },
  ],
};
