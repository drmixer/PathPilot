import React from "react";

const CareerSelection = ({ careerPaths, setCareerPath, setStage }) => (
  <div style={{ padding: "20px" }}>
    <h2>Choose Your Career Path</h2>
    {Object.entries(careerPaths).map(([key, path]) => (
      <div
        key={key}
        onClick={() => {
          setCareerPath(key);
          setStage("learning");
        }}
        style={{
          border: "1px solid #ccc",
          padding: "10px",
          margin: "10px",
          cursor: "pointer",
        }}
      >
        <h3>{path.title}</h3>
        <p>{path.description}</p>
      </div>
    ))}
  </div>
);

export default CareerSelection;
