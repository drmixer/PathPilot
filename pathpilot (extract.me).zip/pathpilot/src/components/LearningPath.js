import React from "react";
import { learningModules } from "../data/learningModules";

const LearningPath = ({ careerPath }) => {
  const modules = learningModules[careerPath] || [];

  return (
    <div style={{ padding: "20px" }}>
      <h2>Your Learning Path</h2>
      {modules.map((module, index) => (
        <div key={index} style={{ marginBottom: "10px" }}>
          <h3>{module.title}</h3>
          <p>Estimated Time: {module.timeEstimate}</p>
        </div>
      ))}
    </div>
  );
};

export default LearningPath;
