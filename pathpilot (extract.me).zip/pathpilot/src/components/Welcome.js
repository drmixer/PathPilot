import React from "react";

const Welcome = ({ goal, setGoal, setStage }) => (
  <div style={{ textAlign: "center", marginTop: "50px" }}>
    <h1>Welcome to PathPilot AI</h1>
    <p>Your AI-powered learning journey to career success</p>
    <input
      type="text"
      value={goal}
      onChange={(e) => setGoal(e.target.value)}
      placeholder="What would you like to become?"
      style={{ padding: "10px", width: "300px" }}
    />
    <br />
    <button
      onClick={() => setStage("careers")}
      style={{ marginTop: "20px", padding: "10px 20px", cursor: "pointer" }}
    >
      Discover Your Path
    </button>
  </div>
);

export default Welcome;
