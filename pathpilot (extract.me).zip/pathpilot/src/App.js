import React, { useState } from "react";
import Welcome from "./components/Welcome";
import CareerSelection from "./components/CareerSelection";
import LearningPath from "./components/LearningPath";
import { careerPaths } from "./data/careerPaths";

const App = () => {
  const [stage, setStage] = useState("welcome");
  const [goal, setGoal] = useState("");
  const [careerPath, setCareerPath] = useState(null);

  return (
    <div>
      {stage === "welcome" && <Welcome goal={goal} setGoal={setGoal} setStage={setStage} />}
      {stage === "careers" && (
        <CareerSelection
          careerPaths={careerPaths}
          setCareerPath={setCareerPath}
          setStage={setStage}
        />
      )}
      {stage === "learning" && <LearningPath careerPath={careerPath} />}
    </div>
  );
};

export default App;
