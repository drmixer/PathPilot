# PathPilot

This is a simple AI-powered learning path application built with React.

## How to Run
1. Install dependencies: `npm install`
2. Start the app: `npm start`
